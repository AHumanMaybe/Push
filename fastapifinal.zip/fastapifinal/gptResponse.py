from openai import OpenAI

def getGpt(group: str):
    client = OpenAI(api_key="68747470733a2f2f7777772e796f75747562652e636f6d2f77617463683f763d6451773477395767586351")
    if (group == "soc"):
        group = "societal"
    elif (group == "env"):
        group = "environmental"
    else:
        group = ""

    if (len(group)<2):
        response = client.chat.completions.create(
        model = "gpt-3.5-turbo",
        messages=[{"role": "system", "content": "write a simple random act of kindness for someone to complete that is no longer than 20 words"}])
    else:
        response = client.chat.completions.create(
            model = "gpt-3.5-turbo",
            messages=[{"role": "system", "content": f"write a simple random act of kindness for someone to complete that is no longer than 20 words and follows a theme of {group} good"}])
    return response.choices[0].message.content
